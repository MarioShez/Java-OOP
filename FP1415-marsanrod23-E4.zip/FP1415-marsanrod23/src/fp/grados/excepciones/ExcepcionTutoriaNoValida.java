package fp.grados.excepciones;

public class ExcepcionTutoriaNoValida extends RuntimeException{
	
	private static final long serialVersionUID = 1L;

	public ExcepcionTutoriaNoValida(){
	
	}

	public ExcepcionTutoriaNoValida(String s){
	super(s);
	}
	
	
	
		
}
