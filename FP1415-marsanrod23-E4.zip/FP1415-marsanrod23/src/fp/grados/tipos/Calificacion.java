
package fp.grados.tipos;

public enum Calificacion {
	
	SUSPENSO ,APROBADO, NOTABLE, SOBRESALIENTE, MATRICULA_DE_HONOR
}
