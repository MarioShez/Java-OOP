package fp.grados.tipos;

public enum Convocatoria {
	
	PRIMERA, SEGUNDA, TERCERA
}
