package fp.grados.tipos.test;



public class TestBidireccionales {

	public static void main(String[] args) {
		
	
	}
}
