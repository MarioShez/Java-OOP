package fp.grados.tipos;

public enum TipoEspacio {
	
	TEORIA, LABORATORIO, SEMINARIO, EXAMEN, OTRO
}
