package fp.grados.tipos;

public enum TipoBeca {
	
	ORDINARIA, MOVILIDAD, EMPRESA
}
