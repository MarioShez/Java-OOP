package fp.grados.tipos;

public enum Categoria {
	
	CATEDRATICO, TITULAR, CONTRATADO_DOCTOR, COLABORADOR, AYUDANTE_DOCTOR, AYUDANTE, INTERINO
	
	
	
	
}
